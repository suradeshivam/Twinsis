import React from "react";

const Appointments = () => {
  return <div className="text-3xl  font-semibold">Appointments</div>;
};

export default Appointments;
