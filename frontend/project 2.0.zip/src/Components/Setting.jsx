import React from "react";

const Setting = () => {
  return <div className="text-3xl  font-semibold">Setting</div>;
};

export default Setting;
