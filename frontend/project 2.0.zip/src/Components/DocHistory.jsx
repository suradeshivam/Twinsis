import React from "react";

const DocHistory = () => {
  return <div className="text-3xl  font-semibold">DocHistory</div>;
};

export default DocHistory;
