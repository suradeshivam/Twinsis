import React from "react";

const Calender = () => {
  return <div className="text-3xl  font-semibold">Calender</div>;
};

export default Calender;
