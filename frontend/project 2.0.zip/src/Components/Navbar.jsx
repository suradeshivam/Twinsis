import React from "react";

const Navbar = () => {
  return (
    <div className="h-16 rounded-md m-2  text-6xl bg-white  flex justify-center">
      Navbar
    </div>
  );
};

export default Navbar;
