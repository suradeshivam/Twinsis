import React from "react";

const Analytics = () => {
  return <div className="text-3xl font-semibold">Analytics</div>;
};

export default Analytics;
