import React from "react";

const Profile = () => {
  return <div className="text-3xl  font-semibold">Profile</div>;
};

export default Profile;
