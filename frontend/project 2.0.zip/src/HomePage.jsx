import React from "react";

const HomePage = () => {
  return <div className="h-96 bg-blue-200">HomePage</div>;
};

export default HomePage;
